#include <stdio.h>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>

    int main () {

    int i;

    i = 1;
    while (1) {
        i = i + 10000000;
        printf("%d\n", i);

    }
}
