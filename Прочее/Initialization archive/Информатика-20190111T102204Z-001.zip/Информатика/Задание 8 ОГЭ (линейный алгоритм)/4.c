#include <stdio.h>

int main(){
    int a;
    int b;

    a = 12;
    b = 18;
    b = 3*(a+b)/b;
    a = 10*b+a;

    printf("%d", a);
return(0);
}
