#include <conio.h>
#include <stdio.h>

int main () {

    int control;

    control=getch();
    //scanf ("%d", &control);
    printf ("%d", control);

    return(0);
}
