#ifndef MyFuntions_H_
#define MyFuntions_H_

int move (int*x, int*y, int direction);
int DrawMap (char **Map);

#endif // MyFuntions_H_
